# Study 03 — Scan Lines Warp

## What it does
The third step of the sequence. The sample picture is drawn as scan lines (as in study 02), and the person can physically push, pull, spread and squeeze the lines. Because the picture is the signal for the lines, the picture travels with them. The warp is kept in a displacement field, so successive gestures accumulate until the person resets.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Stage canvas (`#cv` inside `#stage`) | Full-bleed black canvas with 140 horizontal scan lines. It receives all pointer and wheel input (`touch-action: none`). |
| Tag + hint | `03 / warp · scan lines` top-left; hint "the picture travels with the lines you move" top-right (hidden under 520px wide). |
| Control bar (`.bar`) | Bottom-pinned panel with the instruction "drag to pull lines · pinch to spread or squeeze them", a state readout (`#state`) and a second line of mouse instructions. |
| Brush ring | A faint circle (`rgba(232,232,232,.35)`) drawn at the touch or cursor position showing the area of influence. |
| State readout (`#state`) | Shows `untouched` or `warped`. |
| Displacement field | A 72 × 48 grid (`FX`, `FY`), each node holding how far that spot has moved, in picture heights. It is interpolated bilinearly into a per-point warp. |

## User actions, feedback, states and transitions
| Action | Effect | Feedback |
|---|---|---|
| Drag (one finger or the mouse) | Pulls nearby lines along with the pointer. Brush radius is 12% of the picture height with a Gaussian falloff. | Ring follows the pointer; lines move live; state becomes `warped`. |
| Pinch (two fingers) | Spreads or squeezes the lines around the midpoint and carries them with the midpoint. | Ring at the midpoint, radius scales with finger distance (minimum 14% of picture height). |
| Mouse wheel / trackpad pinch (`ctrlKey`) | Scroll spreads or squeezes around the cursor (trackpad pinch is more sensitive). | Ring appears and fades 400ms after the last wheel event. |
| Double-tap (under 300ms between taps) or double-click | Clears the field and returns to the original lines. | State returns to `untouched`. |
| Pointer down | Shows the ring and starts tracking the pointer. | Ring appears. |
| Pointer up / cancel | Stops tracking; the ring is removed when no pointers remain. | Ring disappears; the warp stays. |
| Window resize | Redraws at the new size. | Warp is kept because it is stored relative to the picture. |

States: `untouched` (no warp, rendering skips the warp function) and `warped` (any edit has been made). The warp is not animated back; it only resets on double-tap or double-click. Rendering is coalesced with `requestAnimationFrame` (`ask()`).

Fixed rendering parameters: `lines: 140`, `angle: 0`, `weight: 1.3`, `depth: 0.08`.

## Where things are implemented (`index.html`)
| Concern | Lines (approx.) |
|---|---|
| Styles: tokens, stage, bar, `.bar` overrides for this study | 4–44 |
| Markup: stage, tag, hint, bar | 46–53 |
| `Scan` core (`toGrey`, `sample`, `fit`, `draw` with the `warp` hook, `canvasFit`, `loadImage`) | 57–112 |
| Refs and state (`G`, `R`, `queued`, `edits`) | 114–115, 119 |
| Displacement field `FX`/`FY`, `fieldAt`, `warp` | 117–126 |
| `brush(cx, cy, radius, fn)`: applies a move to field nodes near a point | 128–139 |
| `render()` and `ask()`; the ring overlay | 140–147 |
| Pointer tracking (`pts`, `pinch`, `lastTap`), `pointerdown`, `pointermove` (drag and pinch), `pointerup` / `pointercancel` | 149–175 |
| `wheel` handler | 176–180 |
| `dblclick` reset | 181 |
| Sample image load and resize listener | 183–184 |

The sample image is embedded at line 183 as a base64 data URI and must stay on one line.

## Hand-off notes for the connected prototype
- Study state to carry: the field arrays `FX`/`FY` (72 × 48 floats) plus `edits`. These fully describe the warp. `Scan.draw` accepts any function `warp(x, y) -> [dx, dy]`, so a later step can reuse or replace it.
- Rendering options are hard-coded here (`lines: 140`, `angle: 0`, `weight: 1.3`). In a connected flow they would come from study 02's `P`.
- The picture is the embedded sample. Swap line 183 for the picture captured in study 01.

## External dependencies and assets
- No npm packages, no build step, no framework. Plain HTML, CSS and JavaScript (Canvas 2D, Pointer Events).
- Font: IBM Plex Mono from Google Fonts (`<link>`). It falls back to system monospace fonts when offline.
- Sample picture: embedded in `index.html` as a base64 JPEG, 720 × 481. The same file is also provided as `assets/sample.jpg` for reference or reuse. The page does not read this file at runtime.

## Run
Open `index.html` directly, or serve the folder: `npm start` (or `python3 -m http.server 8080`). Test touch gestures on a touch device or with browser device emulation.
