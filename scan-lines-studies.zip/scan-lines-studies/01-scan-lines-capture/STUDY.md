# Study 01 — Scan Lines Capture

## What it does
The first step of the sequence. The person supplies a source picture, either by taking one with the device camera or by uploading an image file. The picture is shown on a black stage inside a thin frame. It is the signal that later studies turn into scan lines (Rutt/Etra style: the brightness under each line lifts it). This study only captures and previews the picture; it does not draw lines yet.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Stage canvas (`#cv`) | Full-bleed black canvas that shows the chosen picture, contained and centred, with a 1px `#333` border. |
| Tag + hint | Top-left `01 / capture · scan lines` label; top-right hint "the picture becomes the signal for the lines" (hidden under 520px wide). |
| Placeholder frame (`#frame`) | Empty-state box with corner brackets and the text "no picture yet / take one or upload one below". |
| Control bar (`.bar`) | Bottom-pinned panel with a header ("source picture" and a `#dims` readout), two choice buttons and a status line. |
| Take a picture | `<input type="file" accept="image/*" capture="user" id="take">`. Opens the camera on phones and tablets. |
| Upload a picture | `<input type="file" accept="image/*" id="pick">`. Opens the file picker. |
| Status line (`#status`) | `role="status"` text that reports progress and errors. |

## User actions, feedback, states and transitions
- **Empty state:** placeholder frame visible, `#dims` shows "—", status says "Nothing leaves your device. The picture stays in this page."
- **Choose a file (camera or upload):**
  1. Type check. If it is not `image/*` and has no known image extension, status becomes "That file is not a picture…" with the `.err` class, and nothing changes.
  2. Status becomes "Reading <name>…".
  3. The file is loaded through an object URL.
  4. On success: the previous object URL is revoked, the placeholder frame is hidden, `#dims` shows `width × height`, status becomes "Picture ready · X.X MB. Choose again to replace it.", and the canvas redraws.
  5. On failure: the object URL is revoked and status shows an error. HEIC/HEIF files get a specific message ("Set the camera to 'Most compatible' or upload a JPEG"); anything else gets "That file could not be read as a picture."
- **Replace:** choosing again replaces the picture. The input value is reset after each change, so the same file can be picked twice.
- **Resize:** the canvas re-renders on window resize.
- Controls use a hover border change and a visible focus ring. The choice labels are keyboard accessible through their hidden inputs.
- **Not implemented here:** scan-line rendering, sliders, and any hand-off to another screen.

## Where things are implemented (`index.html`)
| Concern | Lines (approx.) |
|---|---|
| Styles: tokens, stage, bar, buttons, range styling | 4–56 (`:root` tokens at the top; `.frame` 41, `.choices` 46) |
| Markup: stage, tag, hint, frame, bar | 58–72 |
| `Scan` core: `toGrey`, `sample`, `fit`, `draw`, `canvasFit`, `loadImage` | 76–131 |
| State (`pic`, `picURL`) and `render()` | 133–141 |
| `use(file)`: validation, loading, messages, state changes | 142–162 |
| Input wiring (`change` on `#take` and `#pick`) and resize | 163–164 |

Layout details: `render()` fits the picture with padding `[top 48, right 16, bottom 190, left 16]` so it clears the bottom bar.

## Hand-off notes for the connected prototype
- The study's output is `pic`, an `HTMLImageElement` (plus its object URL). Studies 02 and 03 currently use an embedded sample image instead. To connect them, pass the captured picture through `Scan.toGrey(pic, 260)` to get the grey signal `G`.
- `Scan.draw` and `Scan.toGrey` are present but unused in this study. The `Scan` block is byte-identical in all three studies.

## External dependencies and assets
- No npm packages, no build step, no framework. Plain HTML, CSS and JavaScript (Canvas 2D).
- Font: IBM Plex Mono from Google Fonts (`<link>` in the page). Without network access it falls back to `SF Mono`, `ui-monospace`, `Menlo` or `Consolas`.
- No image assets. The picture comes from the user at runtime and never leaves the device.
- Browser features used: `<input capture>`, `URL.createObjectURL`, Canvas 2D, CSS `aspect-ratio`, `backdrop-filter`.

## Run
Open `index.html` directly, or serve the folder: `npm start` (or `python3 -m http.server 8080`).
