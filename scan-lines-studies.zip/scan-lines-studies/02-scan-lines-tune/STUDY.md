# Study 02 — Scan Lines Tuner

## What it does
The second step of the sequence. A sample picture is rendered as scan lines: each line is lifted by the brightness of the picture beneath it. Three sliders change how the lines are drawn (how many, which direction, how heavy), and the picture redraws as the person slides.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Stage canvas (`#cv`) | Full-bleed black canvas with the scan-line drawing, contained and centred. |
| Tag + hint | `02 / tune · scan lines` top-left; hint "brightness lifts every line · sample picture" top-right (hidden under 520px wide). |
| Control bar (`.bar`) | Bottom-pinned panel headed "lines / slide to redraw", with three slider rows in a 3-column grid (1 column under 560px). |
| Slider "how many" (`#lines`) | Range 20–300, step 1, default 110. Readout: `N lines`. |
| Slider "direction" (`#angle`) | Range 0–180, step 1, default 0. Readout: `N°`, with " horizontal" at 0 and 180 and " vertical" at 90. |
| Slider "density" (`#weight`) | Range 0.3–4, step 0.05, default 1.4. Readout: `N.NN px ink` (line thickness). |
| Readouts (`#o_lines`, `#o_angle`, `#o_weight`) | `<output>` elements next to each label, updated live. |

## User actions, feedback, states and transitions
- **Load:** the embedded sample JPEG is decoded and reduced to a grey array (max side 260) and the first render happens. Until that finishes the canvas is just black.
- **Drag any slider (`input` event):** the value in the `P` state object and its readout update immediately, and a redraw is queued.
- **Redraw coalescing:** many `input` events in one frame produce one render through `requestAnimationFrame` (`ask()` and the `queued` flag).
- **Resize:** the canvas is re-fitted and redrawn.
- **Fixed rendering parameters:** lift `depth: 0.08`, smoothing 0.3 (the `Scan.draw` default), ink `#e8e8e8`.
- **Layout switch:** below 560px wide the picture reserves 250px at the bottom (the stacked controls are taller), otherwise 150px.
- Slider thumbs are flat blocks with a visible focus ring. There is no animation between values; every change is an immediate redraw.

## Where things are implemented (`index.html`)
| Concern | Lines (approx.) |
|---|---|
| Styles: tokens, stage, bar, range styling; slider grid `.ctls` / `.ctl` | 4–45 (`.ctls` at 41–44) |
| Markup: stage, tag, hint, bar, three sliders | 47–58 |
| `Scan` core (`toGrey`, `sample`, `fit`, `draw`, `canvasFit`, `loadImage`) | 62–117 |
| Slider state `P`, readout formatters `fmt` | 119–125 |
| `render()` (fit and draw), `ask()` (queued redraw) | 126–132 |
| Slider wiring (`input` listeners, initial readouts) | 133–137 |
| Sample image load, grey conversion, resize listener | 138–139 |

The sample image is embedded in line 138 as a base64 data URI. That keeps the page fully self-contained, so it must stay a single line.

## Hand-off notes for the connected prototype
- Study state is the plain object `P = { lines, angle, weight }`. These are exactly the options `Scan.draw` takes (plus the fixed `depth`), so they can be carried forward to study 03, which currently hard-codes `lines: 140, angle: 0, weight: 1.3`.
- The grey signal `G` comes from `Scan.toGrey(img, 260)`. Swapping the embedded sample for the picture captured in study 01 is a one-line change at line 138.

## External dependencies and assets
- No npm packages, no build step, no framework. Plain HTML, CSS and JavaScript (Canvas 2D).
- Font: IBM Plex Mono from Google Fonts (`<link>`). It falls back to system monospace fonts when offline.
- Sample picture: embedded in `index.html` as a base64 JPEG, 720 × 481. The same file is also provided as `assets/sample.jpg` for reference or reuse. The page does not read this file at runtime.

## Run
Open `index.html` directly, or serve the folder: `npm start` (or `python3 -m http.server 8080`).
