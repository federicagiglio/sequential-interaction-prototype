# Scan Lines — interaction studies

Three standalone studies meant to become one sequential prototype:

| # | Folder | Step | Interaction |
|---|---|---|---|
| 01 | `01-scan-lines-capture/` | Capture | Take or upload the source picture |
| 02 | `02-scan-lines-tune/` | Tune | Sliders for line count, direction and ink weight |
| 03 | `03-scan-lines-warp/` | Warp | Drag, pinch or scroll to warp the lines (and the picture with them) |

Each folder has an `index.html` (the complete study, unchanged from the published version), a `STUDY.md` (behaviour and code map), and a `package.json` with a static-server start script. Studies 02 and 03 also include `assets/sample.jpg`, a copy of the sample picture that is embedded in their HTML.

## Run
No install or build is needed. Use any one of these:
- Open `index.html` in a modern browser (Chrome, Safari, Firefox, Edge).
- Run `npm start` inside a study folder. This needs Node 18+ and uses `serve` on http://localhost:8080.
- Run `python3 -m http.server 8080` inside a study folder.

Use a local server (not `file://`) when testing the camera input on mobile. Camera capture also requires HTTPS or localhost.

## Shared code
All three pages contain an identical `Scan` module (`toGrey`, `sample`, `fit`, `draw`, `canvasFit`, `loadImage`). When the studies are joined, extract it into one shared file. The state each step hands to the next is described under "Hand-off notes" in each `STUDY.md`.

## External dependencies
- IBM Plex Mono from Google Fonts. It falls back to system monospace fonts when offline.
- No other runtime dependencies.
